import apisauce from "apisauce";
import customAxios from "utils/customAxios";

export default {
  create: () => {
    const api = apisauce.create({
      axiosInstance: customAxios,
    });

    const setAuthData = (authData) => {
      return api.setHeaders(authData);
    };

    return {
      setAuthData,
      register: (params) => api.post(`/api/auth/register`, params),
      login: (params) => api.post(`/api/auth/login`, params),
      getConversationById: (params) =>
        api.get(`/api/auth/getConversationById`, params),
      getMessageThreads: () => api.get(`/api/auth/getMessageThreads`),
      getUserProfile: () => api.get(`/api/auth/user-profile`),
      updateUserPassword: (params) =>
        api.post(`/api/auth/updateUserPassword`, params),
      updateUserProfile: (params) =>
        api.post(`/api/auth/updateUserProfile`, params),
      postMessageById: (params) =>
        api.post(`/api/auth/postMessageById`, params),
      authRefresh: (params) => api.post(`/api/auth/refresh`, params),
      logout: (params) => api.post(`/api/auth/logout`, params),
    };
  },
};
