import AuthHeader from "partials/Header/AuthHeader";
import Sidebar from "partials/Sidebar";
import ProtectedRoute from "components/shared/ProtectedRoute";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { userSelector } from "slices/user";
import { fetchUser } from "slices/user";

const AuthLayout = ({ children }) => {
  return (
    <>
      <ProtectedRoute>
        <div id="app">
          <div className="main-wrapper">
            <AuthHeader />
            <div className="main-sidebar sidebar-style-2">
              <Sidebar />
            </div>
            {/* Main Content */}
            <div className="main-content">{children}</div>
          </div>
        </div>
      </ProtectedRoute>
    </>
  );
};

export default AuthLayout;
