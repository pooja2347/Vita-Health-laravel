const GuestLayout = () => {
    return(
    <>
    </>);
};

export default GuestLayout;