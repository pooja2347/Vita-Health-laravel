import filter from "lodash/filter";

const tableFilter = ({ data, q, date, staticFilters }) => {
  if (!data) {
    return [];
  }

  let dataTemp = data;
  if (q) {
    dataTemp = filter(dataTemp, function (item) {
      return item.toLowerCase().includes(q.toLowerCase());
    });
  }

  if (date) {
    dataTemp = filter(dataTemp, { date: date });
  }

  if (staticFilters) {
    dataTemp = filter(dataTemp, { staticFilters });
  }

  return dataTemp;
};

export default tableFilter;
