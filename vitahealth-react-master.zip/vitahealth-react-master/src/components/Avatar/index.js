import Avatar from "react-avatar";

const ProfileAvatar = ({ size, name, image }) => {
  return (
    <>
      {image ? (
        <Avatar
          name={name}
          round="150px"
          color={"#E1EBFF"}
          fgColor={"#7C8EFC"}
          size={size}
          src={image}
        />
      ) : (
        <Avatar
          name={name}
          round="150px"
          color={"#E1EBFF"}
          fgColor={"#7C8EFC"}
          size={size}
        />
      )}
    </>
  );
};
export default ProfileAvatar;
