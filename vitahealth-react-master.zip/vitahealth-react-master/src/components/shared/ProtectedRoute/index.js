import { useEffect } from "react";
import LoginPage from "pages/LoginPage";
import { useDispatch, useSelector } from "react-redux";
import { fetchUser, userSelector } from "slices/user";

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useSelector(userSelector);

  let dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchUser());
  }, []);

  if (!loading) {
    return <>{user ? <>{children}</> : <LoginPage />}</>;
  }
};
export default ProtectedRoute;
