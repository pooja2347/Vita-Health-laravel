import { useEffect, useState } from "react";
import DataTable from "react-data-table-component";

const Pagination = ({
  rowsPerPage,
  rowCount,
  onChangePage,
  onChangeRowsPerPage,
  currentPage,
}) => {
  const [pages, setPages] = useState(0);
  const [pageItems, setPageItems] = useState([]);

  useEffect(() => {
    let pagesTemp = getNumberOfPages(rowCount, rowsPerPage);
    let pageItemsTemp = toPages(pagesTemp);

    setPages(pagesTemp);
    setPageItems(pageItemsTemp);
  }, [rowsPerPage, rowCount]);

  const handleBackButtonClick = (e) => {
    e.preventDefault();
    if (currentPage !== 1) {
      onChangePage(currentPage - 1);
    }
  };

  const handleNextButtonClick = (e) => {
    e.preventDefault();
    onChangePage(currentPage + 1);
  };

  const handlePageNumber = (e, page) => {
    e.preventDefault();
    onChangePage(Number(page));
  };

  const getNumberOfPages = (rowCount, rowsPerPage) => {
    return Math.ceil(rowCount / rowsPerPage);
  };

  const toPages = (pages) => {
    const results = [];

    for (let i = 1; i < pages + 1; i++) {
      results.push(i);
    }

    return results;
  };

  const nextDisabled = currentPage === pageItems.length;
  const previosDisabled = currentPage === 1;

  return (
    <div className="vh-pagination-block d-flex justify-content-between align-items-center">
      <div className="vh-perpage-row d-flex">
        <p className="mb-0">Row Per Page:</p>
        <select
          className="border-0"
          onChange={(e) => {
            onChangeRowsPerPage(e?.target?.value);
          }}
        >
          <option>10</option>
          <option>20</option>
          <option>30</option>
          <option>40</option>
        </select>
      </div>
      <nav className="vh-pagination-menu" aria-label="...">
        <ul className="pagination">
          <li className="page-item">
            <a
              href="#"
              className="page-link"
              onClick={handleBackButtonClick}
              disabled={previosDisabled}
              aria-disabled={previosDisabled}
              aria-label="previous page"
            >
              Prev
            </a>
          </li>
          {pageItems.map((page) => {
            const className =
              page === currentPage ? "page-item active" : "page-item";

            return (
              <li key={page} className={className}>
                <a
                  href="#"
                  className="page-link"
                  onClick={(e) => handlePageNumber(e, page)}
                >
                  {page}
                </a>
              </li>
            );
          })}
          <li className="page-item">
            <a
              href="#"
              className="page-link"
              onClick={handleNextButtonClick}
              disabled={nextDisabled}
              aria-disabled={nextDisabled}
              aria-label="next page"
            >
              Next
            </a>
          </li>
        </ul>
      </nav>
    </div>
  );
};

const VhTable = (props) => {
  return <DataTable {...props} pagination paginationComponent={Pagination} />;
};
export default VhTable;
