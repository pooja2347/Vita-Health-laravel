import logo from 'assets/img/logo.png';
import {
  Link,
} from "react-router-dom";

const GuestHeader = ({ isRegister }) => {
  return (
    <>
      <div className="vh-reg-log-header d-flex justify-content-between align-items-center">
        <div className="vh-logo">
          <Link to="/"><img src={logo} alt="Logo" loading="lazy" /></Link>
        </div>
        {isRegister ? (<div className="vh-log-sign-btn">
          <p className="mb-0">Already have an account?<Link to="/login" className="btn btn-outline-primary ms-2">Login</Link></p>
        </div>) : (<div className="vh-log-sign-btn">
          <p className="mb-0">Don't have an account?<Link to="/register" className="btn btn-outline-primary ms-2">Register</Link></p>
        </div>)}

      </div>
    </>);
};

export default GuestHeader;