import Avatar from "components/Avatar";
import { Link } from "react-router-dom";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { userSelector } from "slices/user";
import { setSidebar, settingsSelector } from "slices/settings";
import { UncontrolledDropdown, DropdownToggle, DropdownMenu } from "reactstrap";

const AuthHeader = () => {
  const { user, loading } = useSelector(userSelector);
  const dispatch = useDispatch();
  const { sidebarOpen } = useSelector(settingsSelector);

  const doLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem("vita-health-token");
    window.location.reload();
  };

  return (
    <>
      <nav className="navbar navbar-expand-lg main-navbar">
        <div className="form-inline mr-auto">
          <ul className="navbar-nav mr-3 align-items-center">
            <li>
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  dispatch(setSidebar(!sidebarOpen));
                }}
                className="nav-link nav-link-lg"
              >
                <i className="fas fa-bars" />
              </a>
            </li>
            <li className="ml-4">
              <p className="mb-0">
                Today:{" "}
                <span className="text-primary">
                  {moment().format("DD.MM.YYYY")}
                </span>
              </p>
            </li>
          </ul>
        </div>
        <ul className="navbar-nav navbar-right ms-auto align-items-center">
          <UncontrolledDropdown
            nav
            inNavbar
            className="dropdown dropdown-list-toggle"
          >
            <DropdownToggle
              nav
              caret
              className="nav-link nav-link-lg message-toggle"
            >
              <i className="far fa-envelope" />
            </DropdownToggle>
            <DropdownMenu
              end
              className="dropdown-menu dropdown-list dropdown-menu-right"
            >
              <div className="dropdown-header">Messages</div>
              <div className="dropdown-list-content dropdown-list-message">
                <a href="#" className="dropdown-item dropdown-item-unread">
                  <div className="dropdown-item-avatar">
                    <Avatar name="Wim Mostmans" size={36} round="150px" />
                    <div className="is-online" />
                  </div>
                  <div className="dropdown-item-desc">
                    <b>Kusnaedi</b>
                    <p>Hello, Bro!</p>
                    <div className="time">10 Hours Ago</div>
                  </div>
                </a>
              </div>
              <div className="dropdown-footer text-center">
                <Link to="messages">
                  View All <i className="fas fa-chevron-right" />
                </Link>
              </div>
            </DropdownMenu>
          </UncontrolledDropdown>
          <UncontrolledDropdown
            nav
            inNavbar
            className="dropdown dropdown-list-toggle"
          >
            <DropdownToggle
              nav
              caret
              className="nav-link notification-toggle nav-link-lg"
            >
              <i className="far fa-bell" />
            </DropdownToggle>
            <DropdownMenu
              end
              className="dropdown-menu dropdown-list dropdown-menu-right"
            >
              <div className="dropdown-header">Notifications</div>
              <div className="dropdown-list-content dropdown-list-icons">
                <a href="#" className="dropdown-item">
                  <div className="dropdown-item-icon bg-info text-white">
                    <i className="fas fa-bell" />
                  </div>
                  <div className="dropdown-item-desc">
                    Welcome to Stisla template!
                    <div className="time">Yesterday</div>
                  </div>
                </a>
              </div>
            </DropdownMenu>
          </UncontrolledDropdown>
          <UncontrolledDropdown nav inNavbar>
            <DropdownToggle
              nav
              caret
              className="nav-link dropdown-toggle nav-link-lg nav-link-user"
            >
              <Avatar
                name={`${user?.firstname} ${user?.lastname}`}
                round="150px"
                size="36"
              />
              <div className="d-sm-none d-lg-inline-block text-black">
                Hello!{" "}
                <span className="text-primary">
                  {user?.firstname} {user?.lastname}
                </span>
              </div>
            </DropdownToggle>
            <DropdownMenu end className="dropdown-menu dropdown-menu-right">
              <Link to="/profile" className="dropdown-item has-icon">
                <i className="far fa-user" /> Profile
              </Link>
              <div className="dropdown-divider" />
              <a
                href="#"
                onClick={(e) => {
                  doLogout(e);
                }}
                className="dropdown-item has-icon text-danger"
              >
                <i className="fas fa-sign-out-alt" /> Logout
              </a>
            </DropdownMenu>
          </UncontrolledDropdown>
        </ul>
      </nav>
    </>
  );
};
export default AuthHeader;
