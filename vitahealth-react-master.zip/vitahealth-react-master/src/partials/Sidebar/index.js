import { useLocation } from "react-router-dom";
import logo from "assets/img/logo.png";
import logoMini from "assets/img/logo-mini.png";
import { Link } from "react-router-dom";
import { IoChatbubbleEllipsesSharp } from "react-icons";

const Sidebar = () => {
  const location = useLocation();
  //destructuring pathname from location
  const { pathname } = location;
  const splitLocation = pathname.split("/");
  const menuItems = [
    {
      name: "Dashboard",
      url: "/",
      icon: "fas fa-fire",
    },
    {
      name: "Appointments",
      url: "/appointments",
      icon: "fas fa-calendar-alt",
    },
    {
      name: "Patient Management",
      url: "/patients",
      icon: "fas fa-procedures",
    },
    {
      name: "Profile Management",
      url: "/profile",
      icon: "fas fa-id-card-alt",
    },
    {
      name: "Messages",
      url: "/messages",
      icon: "fas fa-comment-dots",
    },
    {
      name: "Doctor's Management",
      url: "/doctor",
      icon: "fas fa-user-md",
    },
    {
      name: "SHR Management",
      url: "/shrmanagement",
      icon: "fas fa-chart-pie",
    },
  ];
  return (
    <aside id="sidebar-wrapper">
      <div className="sidebar-brand">
        <Link to="/" className="vh-main-logo">
          <img src={logo} alt="Logo" loading="lazy" />
        </Link>
      </div>
      <div className="sidebar-brand sidebar-brand-sm">
        <Link to="/">
          <img
            src={logoMini}
            className="img-fluid"
            width="30px"
            alt="Logo"
            loading="lazy"
          />
        </Link>
      </div>
      <ul className="sidebar-menu">
        {menuItems.map((item, index) => (
          <li
            key={item?.name}
            className={
              "/" + splitLocation[1] === item.url
                ? "nav-item active"
                : "nav-item"
            }
          >
            {item.hasOwnProperty("external") && item.external ? (
              <a href={item?.url} className="nav-link">
                <i className={item?.icon}></i>
                <span>{item?.name}</span>
              </a>
            ) : (
              <Link to={item?.url} className="nav-link">
                <i className={item?.icon}></i>
                <span>{item?.name}</span>
              </Link>
            )}
          </li>
        ))}
      </ul>
    </aside>
  );
};

export default Sidebar;
