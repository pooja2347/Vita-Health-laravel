const Footer = () => {
    return(
    <footer>
        <p className="mb-0">Copyright © Vita Health 2022.</p>
    </footer>
    )
};

export default Footer;