import { createSlice } from '@reduxjs/toolkit'

export const initialState = {
    sidebarOpen : localStorage.getItem('sidebar-state') === 'true' ? true : false  
}

// A slice for settings with our three reducers
const settingsSlice = createSlice({
    name: 'settings',
    initialState,
    reducers: {
      setSettingsSidebar: (state, {payload}) => {
        state.sidebarOpen = payload
      },
    },
  })

  // Three actions generated from the slice
export const { setSettingsSidebar } = settingsSlice.actions

// A selector
export const settingsSelector = (state) => state.settings

// The reducer
export default settingsSlice.reducer

// Asynchronous thunk action
export function setSidebar(val) {
  return async (dispatch) => {
    localStorage.setItem('sidebar-state', val)
    dispatch(setSettingsSidebar(val))
    
  }
}