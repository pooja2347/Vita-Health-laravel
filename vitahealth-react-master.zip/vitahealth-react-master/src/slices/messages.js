import { createSlice } from "@reduxjs/toolkit";
import Api from "services/Api";
import { toast } from "react-toastify";

const api = Api.create();

export const initialState = {
  conversationLoading: false,
  threadLoading: false,
  conversationHasErrors: false,
  threadHasErrors: false,
  messages: [],
  threads: [],
};

// A slice for messages with our three reducers
const messagesSlice = createSlice({
  name: "messages",
  initialState,
  reducers: {
    getConversationByIdRequest: (state) => {
      state.conversationLoading = true;
    },
    getConversationByIdSuccess: (state, { payload }) => {
      state.messages = payload?.data?.messages;
      state.conversationLoading = false;
      state.conversationHasErrors = false;
    },
    getConversationByIdFailure: (state) => {
      state.conversationLoading = false;
      state.conversationHasErrors = true;
    },
    getMessageThreadsRequest: (state) => {
      state.threadLoading = true;
    },
    getMessageThreadsSuccess: (state, { payload }) => {
      state.threads = payload?.data;
      state.threadLoading = false;
      state.threadHasErrors = false;
    },
    getMessageThreadsFailure: (state) => {
      state.threadLoading = false;
      state.threadHasErrors = true;
    },
    postMessageByIdRequest: (state) => {
      state.conversationLoading = true;
    },
    postMessageByIdSuccess: (state, { payload }) => {
      state.messages = payload?.data?.messages;
      state.conversationLoading = false;
      state.conversationHasErrors = false;
    },
    postMessageByIdFailure: (state) => {
      state.conversationLoading = false;
      state.conversationHasErrors = true;
    },
  },
});

// Three actions generated from the slice
export const {
  getConversationByIdRequest,
  getConversationByIdSuccess,
  getConversationByIdFailure,
  getMessageThreadsRequest,
  getMessageThreadsSuccess,
  getMessageThreadsFailure,
  postMessageByIdRequest,
  postMessageByIdSuccess,
  postMessageByIdFailure,
} = messagesSlice.actions;

// A selector
export const messagesSelector = (state) => state.messages;

// The reducer
export default messagesSlice.reducer;

// Asynchronous thunk action
export function getConversationById(params) {
  return async (dispatch) => {
    dispatch(getConversationByIdRequest());

    try {
      const response = await api.getConversationById(params);
      dispatch(getConversationByIdSuccess(response?.data));
    } catch (error) {
      dispatch(getConversationByIdFailure());
    }
  };
}

export function getMessageThreads() {
  return async (dispatch) => {
    dispatch(getMessageThreadsRequest());

    try {
      const response = await api.getMessageThreads();
      dispatch(getMessageThreadsSuccess(response?.data));
    } catch (error) {
      dispatch(getMessageThreadsFailure());
    }
  };
}

export function postMessageById(params, callback = () => {}) {
  return async (dispatch) => {
    dispatch(postMessageByIdRequest());

    try {
      const response = await api.postMessageById(params);
      dispatch(postMessageByIdSuccess(response?.data));
      callback();
    } catch (error) {
      dispatch(postMessageByIdFailure());
      toast.error("Something went wrong");
    }
  };
}
