import { combineReducers } from "redux";
import messagesReducer from "./messages";
import settingsReducer from "./settings";
import userReducer from "./user";

const rootReducer = combineReducers({
  messages: messagesReducer,
  settings: settingsReducer,
  user: userReducer,
});
export default rootReducer;
