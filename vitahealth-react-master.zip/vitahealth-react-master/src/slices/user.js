import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import Api from "services/Api";

const api = Api.create();

export const initialState = {
  loading: false,
  hasErrors: false,
  user: [],
};

// A slice for user with our three reducers
const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    getUserRequest: (state) => {
      state.loading = true;
    },
    getUserSuccess: (state, { payload }) => {
      state.user = payload;
      state.loading = false;
      state.hasErrors = false;
    },
    getUserFailure: (state) => {
      state.loading = false;
      state.hasErrors = true;
    },
    updateUserPasswordRequest: (state) => {
      state.loading = true;
    },
    updateUserPasswordSuccess: (state, { payload }) => {
      state.user = payload;
      state.loading = false;
      state.hasErrors = false;
    },
    updateUserPasswordFailure: (state) => {
      state.loading = false;
      state.hasErrors = true;
    },
    doLoginRequest: (state) => {
      state.loading = true;
    },
    doLoginSuccess: (state, { payload }) => {
      state.user = payload?.user;
      state.loading = false;
      state.hasErrors = false;
    },
    doLoginFailure: (state) => {
      state.loading = false;
      state.hasErrors = true;
    },
    doRegisterRequest: (state) => {
      state.loading = true;
    },
    doRegisterSuccess: (state, { payload }) => {
      state.user = payload;
      state.loading = false;
      state.hasErrors = false;
    },
    doRegisterFailure: (state) => {
      state.loading = false;
      state.hasErrors = true;
    },
  },
});

// Three actions generated from the slice
export const {
  getUserRequest,
  getUserSuccess,
  getUserFailure,
  updateUserPasswordRequest,
  updateUserPasswordSuccess,
  updateUserPasswordFailure,
  doLoginRequest,
  doLoginSuccess,
  doLoginFailure,
  doRegisterRequest,
  doRegisterSuccess,
  doRegisterFailure,
} = userSlice.actions;

// A selector
export const userSelector = (state) => state.user;

// The reducer
export default userSlice.reducer;

// Asynchronous thunk action
export function fetchUser() {
  return async (dispatch) => {
    dispatch(getUserRequest());

    try {
      const response = await api.getUserProfile();

      dispatch(getUserSuccess(response?.data));
    } catch (error) {
      dispatch(getUserFailure());
    }
  };
}

export function updateUserPassword() {
  return async (dispatch) => {
    dispatch(updateUserPasswordRequest());

    try {
      const response = await api.updateUserPassword();

      dispatch(updateUserPasswordSuccess(response?.data));
    } catch (error) {
      dispatch(updateUserPasswordFailure());
    }
  };
}

// Asynchronous thunk action
export function doLogin(params, callback = () => {}) {
  return async (dispatch) => {
    dispatch(doLoginRequest());

    try {
      const response = await api.login(params);
      if (response?.data?.user) {
        dispatch(doLoginSuccess(response?.data));
        localStorage.setItem(
          "vita-health-token",
          btoa(response?.data?.access_token)
        );
        toast.success("Login Successful");
        callback();
      } else {
        dispatch(doLoginFailure());
        toast.error("Something went wrong");
      }
    } catch (error) {
      dispatch(doLoginFailure());
    }
  };
}

// Asynchronous thunk action
export function doRegister(params) {
  return async (dispatch) => {
    dispatch(doRegisterRequest());

    try {
      const response = await api.register(params);
      dispatch(doRegisterSuccess(response?.data));
      toast.success("Please check inbox for verification");
    } catch (error) {
      toast.error("Something went wrong");
      dispatch(doRegisterFailure());
    }
  };
}
