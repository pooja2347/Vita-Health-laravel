import "bootstrap/dist/css/bootstrap.min.css";
import "assets/css/style.css";
import "assets/css/components.css";
import "assets/css/custom.css";
import "react-toastify/dist/ReactToastify.css";
import AppointmentPage from "pages/AppointmentPage";
import AppointmentProperties from "pages/AppointmentPage/AppointmentProperties";
import HomePage from "pages/HomePage";
import LoginPage from "pages/LoginPage";
import MessagePage from "pages/MessagePage";
import DoctorPage from "pages/DoctorPage";
import PatientPage from "pages/PatientPage";
import ProfilePage from "pages/ProfilePage";
import RegisterPage from "pages/RegisterPage";
import ShrManagement from "pages/ShrManagement";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";

import { useSelector } from "react-redux";
import { settingsSelector } from "slices/settings";

const App = () => {
  const { sidebarOpen } = useSelector(settingsSelector);
  return (
    <div className={!sidebarOpen ? "sidebar-mini" : ""}>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="appointments" element={<AppointmentPage />} />
          <Route
            exact
            path="appointments/new"
            element={<AppointmentProperties />}
          />
          <Route path="login" element={<LoginPage />} />
          <Route path="doctor" element={<DoctorPage />} />
          <Route path="messages" element={<MessagePage />} />
          <Route path="shrmanagement" element={<ShrManagement />} />
          <Route path="patients" element={<PatientPage />} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="register" element={<RegisterPage />} />
        </Routes>
      </Router>
      <ToastContainer />
    </div>
  );
};

export default App;
