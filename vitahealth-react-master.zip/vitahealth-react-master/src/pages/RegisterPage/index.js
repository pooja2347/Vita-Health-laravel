import Footer from 'partials/Footer';
import GuestHeader from 'partials/Header/GuestHeader';

const RegisterPage = () => {
  return (
    <>
      <div className="vh-log-reg-body">
        <div className="container-fluid">
          <GuestHeader isRegister={true} />
          <div className="vh-customer-form">
            <form>
              <div className="vh-form-block-1">
                <h5>Register yourself in Vita Health</h5>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group form-floating">
                      <input type="text" className="form-control" id="firstname" placeholder="First Name" />
                      <label htmlFor="firstname">First Name</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group form-floating">
                      <input type="text" className="form-control" id="lastname" placeholder="Last Name" />
                      <label htmlFor="lastname">Last Name</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group form-floating">
                      <input type="email" className="form-control" id="emailaddress" placeholder="Email Address" />
                      <label htmlFor="emailaddress">Email Address</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group form-floating">
                      <input type="number" className="form-control" id="mobile" placeholder="Mobile" />
                      <label htmlFor="mobile">Mobile</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group form-floating mb-md-0">
                      <input type="password" className="form-control" id="password" placeholder="Password" />
                      <label htmlFor="password">Password</label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group form-floating mb-0">
                      <input type="password" className="form-control" id="confirmpassword" placeholder="Confirm Password" />
                      <label htmlFor="confirmpassword">Confirm Password</label>
                    </div>
                  </div>
                </div>
              </div>
              <div className="vh-form-block-2 mt-5">
                <h5>Your home</h5>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <select className="form-control" aria-label="Default select example">
                        <option selected>Open this select menu</option>
                        <option value={1}>One</option>
                        <option value={2}>Two</option>
                        <option value={3}>Three</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <select className="form-control" aria-label="Default select example">
                        <option selected>Open this select menu</option>
                        <option value={1}>One</option>
                        <option value={2}>Two</option>
                        <option value={3}>Three</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <select className="form-control" aria-label="Default select example">
                        <option selected>Open this select menu</option>
                        <option value={1}>One</option>
                        <option value={2}>Two</option>
                        <option value={3}>Three</option>
                      </select>
                    </div>
                  </div>
                  <div className="col-md-6 mb-md-0">
                    <div className="form-group form-floating">
                      <input type="number" className="form-control" id="mobile" placeholder="Postal Code" />
                      <label htmlFor="mobile">Postal Code</label>
                    </div>
                  </div>
                  <div className="col-md-12">
                    <div className="form-check vh-custom-checkbox">
                      <label className="form-check-label ps-2" htmlFor="term-condition">
                        <input className="form-check-input" type="checkbox" defaultValue id="term-condition" />
                        I agree with the terms and conditions
                        <span className="vh-custom-checkmark" />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <button type="submit" className="btn btn-primary mt-5 text-uppercase btn-lg">Register</button>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default RegisterPage