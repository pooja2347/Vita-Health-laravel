import AuthLayout from "layouts/AuthLayout";
import VhTable from "components/shared/VhTable";
const PatientPage = () => {
  const ptmanageColumns = [
    {
      name: "Patient Name",
      selector: (row) => row.name,
    },
    {
      name: "Services",
      selector: (row) => row.services,
    },
    {
      name: "Day",
      selector: (row) => row.day,
    },
    {
      name: "Date",
      selector: (row) => row.date,
    },
    {
      name: "Time",
      selector: (row) => row.time,
    },
    {
      name: "Hospital",
      selector: (row) => row.hospital,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
    {
      name: "Action",
      selector: (row) => row.action,
      cell: (row) => (
        <div className="vh-action-btn">
          <a href="#" className="btn btn-outline-primary vh-btn-sm">
            Edit
          </a>
          <a href="#" className="btn btn-outline-primary vh-btn-sm">
            Delete
          </a>
        </div>
      ),
    },
  ];

  const ptmanagedata = [
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
    {
      name: "John Doe",
      services: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022	",
      time: "10:00am",
      hospital: "Saint Jones	",
      status: "Confirm",
    },
  ];
  return (
    <>
      <AuthLayout>
        <section className="section">
          <div className="vh-page-title d-flex justify-content-between align-items-center">
            <div className="vh-haeder-block">
              <h2 className="vh-title mb-0">Patient Management</h2>
              <nav
                className="vh-breadvrumb"
                style={{ "--bs-breadcrumb-divider": "-" }}
                aria-label="breadcrumb"
              >
                <ol className="breadcrumb mb-0">
                  <li className="breadcrumb-item">
                    <a href="#">Dashboard</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Patient Management
                  </li>
                </ol>
              </nav>
            </div>
            <a href="#" className="btn btn-outline-primary text-uppercase">
              Add Patient
            </a>
          </div>
          <div className="card">
            <div className="vh-filter-header">
              <div className="vh-filter vh-patient-managemanet">
                <form>
                  <h4 className="mb-0">Filter</h4>
                  <div className="form-group mb-0">
                    <input
                      type="date"
                      className="form-control"
                      placeholder="Select Date"
                    />
                  </div>
                  <div className="form-group mb-0">
                    <select className="form-control">
                      <option>Select Status</option>
                      <option>Confirm</option>
                      <option>Pending</option>
                    </select>
                  </div>
                  <div className="form-group mb-0">
                    <select className="form-control">
                      <option>Select Hospital</option>
                      <option>Saint Jones</option>
                      <option>Johnson Doe</option>
                    </select>
                  </div>
                  <button type="submit" className="btn btn-primary">
                    Apply Filter
                  </button>
                </form>
              </div>
              <div className="vh-search-element">
                <input
                  className="form-control"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                  data-width={250}
                  style={{ width: "250px" }}
                />
                <button className="btn" type="submit">
                  <i className="fas fa-search" />
                </button>
              </div>
            </div>
            <div className="vh-card-body">
              <div className="vh-appointment-table">
                <VhTable columns={ptmanageColumns} data={ptmanagedata} />
                {/* <table className="table table-bordered mb-0">
                  <thead>
                    <tr>
                      <th scope="col">Patient Name</th>
                      <th scope="col">Services</th>
                      <th scope="col">Day</th>
                      <th scope="col">Date</th>
                      <th scope="col">Time</th>
                      <th scope="col">Hospital</th>
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Monday</td>
                      <td>12-Dec-2022</td>
                      <td>10:00am</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>New John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Friday</td>
                      <td>16-Dec-2022</td>
                      <td>12:00pm</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Johnson Doe</td>
                      <td>Heart Surgery</td>
                      <td>Wednesday</td>
                      <td>21-Dec-2022</td>
                      <td>11:00am</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>New John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Monday</td>
                      <td>16-Dec-2022</td>
                      <td>12:00pm</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Monday</td>
                      <td>12-Dec-2022</td>
                      <td>10:00am</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>New John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Friday</td>
                      <td>16-Dec-2022</td>
                      <td>12:00pm</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Johnson Doe</td>
                      <td>Heart Surgery</td>
                      <td>Wednesday</td>
                      <td>21-Dec-2022</td>
                      <td>11:00am</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-pending">Pending</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>New John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Monday</td>
                      <td>16-Dec-2022</td>
                      <td>12:00pm</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Johnson Doe</td>
                      <td>Heart Surgery</td>
                      <td>Wednesday</td>
                      <td>21-Dec-2022</td>
                      <td>11:00am</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-pending">Pending</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>New John Doe</td>
                      <td>Heart Surgery</td>
                      <td>Monday</td>
                      <td>16-Dec-2022</td>
                      <td>12:00pm</td>
                      <td>Saint Jones</td>
                      <td className="vh-status-confirm">Confirm</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table> */}
              </div>
            </div>
          </div>
        </section>
      </AuthLayout>
    </>
  );
};
export default PatientPage;
