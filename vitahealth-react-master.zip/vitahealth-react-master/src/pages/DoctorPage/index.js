import VhTable from "components/shared/VhTable";
import { Link } from "react-router-dom";
import AppointmentCalendar from "components/AppointmentCalendar";
import AuthLayout from "layouts/AuthLayout";
import visitedPatient from "assets/img/visited-patient.svg";
import totalAppointment from "assets/img/total-appointment.svg";
import totalTodayServices from "assets/img/total-today-services.svg";
import totalServices from "assets/img/total-services.svg";

const DoctorPage = () => {
  const patientColumns = [
    {
      name: "ID Numer",
      selector: (row) => row.id,
    },
    {
      name: "Patient Name",
      selector: (row) => row.name,
    },
    {
      name: "Email",
      selector: (row) => row.email,
    },
    {
      name: "Blood Group",
      selector: (row) => row.blood,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
  ];

  const patientdata = [
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
    {
      id: "#112233",
      name: "Johnson Doe",
      email: "youremail@gmail.com",
      blood: "O -ve",
      status: "Active",
    },
  ];
  const appointmentColumns = [
    {
      name: "Patient Name",
      selector: (row) => row.patient,
    },
    {
      name: "Services",
      selector: (row) => row.services,
    },
    {
      name: "Date",
      selector: (row) => row.date,
    },
    {
      name: "Time",
      selector: (row) => row.time,
    },
    {
      name: "Hospital",
      selector: (row) => row.hospital,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
  ];

  const appointmentdata = [
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
    {
      patient: "Johnson",
      services: "Heart Surgery",
      date: "12-Dec-2022",
      time: "00:00am",
      hospital: "Saint Jones",
      status: "Confirm",
    },
  ];
  const columns = [
    {
      name: "ID Number",
      selector: (row) => row.id,
    },
    {
      name: "Name",
      selector: (row) => row.name,
    },
    {
      name: "Hospital/Clinics",
      selector: (row) => row.hospital,
    },
    {
      name: "Email",
      selector: (row) => row.email,
    },
    {
      name: "Mobile",
      selector: (row) => row.mobile,
    },
    {
      name: "Specialization",
      selector: (row) => row.specialization,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
    {
      name: "Action",
      selector: (row) => row.action,
      cell: (row) => (
        <div className="vh-action-btn">
          <a href="#" className="btn btn-outline-green vh-btn-sm">
            Edit
          </a>
          <a href="#" className="btn btn-outline-orange vh-btn-sm">
            Delete
          </a>
        </div>
      ),
    },
  ];

  const data = [
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
    {
      id: "#111222333",
      name: "Johnson Doe",
      hospital: "Saint Jones	",
      email: "youremail@gmail.com",
      mobile: "+00 123 456 7890",
      specialization: "Dermatology, Cardiac Surgeon",
      status: "Active",
    },
  ];

  return (
    <AuthLayout>
      <section className="section">
        <div className="vh-haeder-block">
          <h2 className="vh-title">Welcome to Dashboard</h2>
        </div>
        <div className="vh-dashboard-header-blocks">
          <div className="row">
            <div className="col-lg-6 col-xl-3">
              <div className="card vh-card-border vh-visited-pateint">
                <div className="vh-card-body">
                  <div className="vh-dash-header-content">
                    <p className="text-orange mb-0">
                      <span>10</span>Total Visited Patient
                    </p>
                    <div className="vh-dash-icon-bg">
                      <img src={visitedPatient} alt="Icon" />
                    </div>
                  </div>
                  <div className="vh-dash-header-title">
                    <Link
                      to="/patients"
                      className="mb-0 text-center d-block py-3 px-2"
                    >
                      Manage Patient
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-xl-3">
              <div className="card vh-card-border vh-total-appointment">
                <div className="vh-card-body">
                  <div className="vh-dash-header-content">
                    <p className="text-green mb-0">
                      <span>16</span>Total Appointments
                    </p>
                    <div className="vh-dash-icon-bg">
                      <img src={totalAppointment} alt="Icon" />
                    </div>
                  </div>
                  <div className="vh-dash-header-title">
                    <Link
                      to="/appointments/new"
                      className="mb-0 text-center d-block py-3 px-2"
                    >
                      Book Appointment on Behalf of your Patient
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-xl-3">
              <div className="card vh-card-border vh-total-today-appointed">
                <div className="vh-card-body">
                  <div className="vh-dash-header-content">
                    <p className="text-primary mb-0">
                      <span>04</span>Today's Total Appointments
                    </p>
                    <div className="vh-dash-icon-bg">
                      <img src={totalTodayServices} alt="Icon" />
                    </div>
                  </div>
                  <div className="vh-dash-header-title">
                    <Link
                      to="/appointments"
                      className="text-center d-block py-3 px-2"
                    >
                      Manage Appointments
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-6 col-xl-3">
              <div className="card vh-card-border vh-total-services">
                <div className="vh-card-body">
                  <div className="vh-dash-header-content">
                    <p className="text-blue mb-0">
                      <span>02</span>Total Services
                    </p>
                    <div className="vh-dash-icon-bg">
                      <img src={totalServices} alt="Icon" />
                    </div>
                  </div>
                  <div className="vh-dash-header-title">
                    <a href="#" className="mb-0 d-block text-center py-3 px-2">
                      Manage Services
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="vh-card-title">
            <h3 className="vh-sub-title">Appointment</h3>
          </div>
          <div className="vh-appointment-cal-sec">
            <AppointmentCalendar />
          </div>
        </div>
        <div className="card">
          <div className="vh-card-title d-flex justify-content-between align-items-center">
            <h3 className="vh-sub-title">Hospital / Consultants List</h3>
            <div className="vh-button-group">
              <a href="#" className="btn btn-outline-primary active vh-btn-32">
                All
              </a>
              <a href="#" className="btn btn-outline-primary vh-btn-32">
                Hospitals
              </a>
              <a href="#" className="btn btn-outline-primary vh-btn-32">
                Consultants
              </a>
            </div>
          </div>
          <div className="vh-hos-consultants">
            <div className="table-responsive">
              <VhTable columns={columns} data={data} />
            </div>
            <div className="vh-view-all-btns d-flex justify-content-between align-items-center">
              <a href="#" className="btn btn-outline-primary vh-btn-lg">
                View all
              </a>
              <a href="#" className="btn btn-primary vh-btn-lg">
                Add More
              </a>
            </div>
          </div>
        </div>
        <div className="vh-appointment-pateint-listing">
          <div className="row">
            <div className="col-md-6">
              <div className="card">
                <div className="vh-card-title d-flex justify-content-between align-items-center">
                  <h3 className="vh-sub-title">Appointment List</h3>
                  <div className="vh-button-group">
                    <a
                      href="#"
                      className="btn btn-outline-primary active vh-btn-32"
                    >
                      All
                    </a>
                    <a href="#" className="btn btn-outline-primary vh-btn-32">
                      Upcoming
                    </a>
                    <a href="#" className="btn btn-outline-primary vh-btn-32">
                      Past
                    </a>
                  </div>
                </div>
                <div className="vh-hos-consultants">
                  <div className="table-responsive">
                    <VhTable
                      columns={appointmentColumns}
                      data={appointmentdata}
                    />
                  </div>
                  <div className="vh-view-all-btns d-flex align-items-center">
                    <a href="#" className="btn btn-primary vh-btn-lg">
                      View all
                    </a>
                    <a href="#" className="btn btn-outline-primary vh-btn-lg">
                      Manage
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <div className="card">
                <div className="vh-card-title d-flex justify-content-between align-items-center">
                  <h3 className="vh-sub-title">Patient List</h3>
                  <div className="vh-button-group">
                    <a
                      href="#"
                      className="btn btn-outline-primary active vh-btn-32"
                    >
                      All
                    </a>
                    <a href="#" className="btn btn-outline-primary vh-btn-32">
                      New
                    </a>
                  </div>
                </div>
                <div className="vh-hos-consultants">
                  <div className="table-responsive">
                    <VhTable columns={patientColumns} data={patientdata} />
                  </div>
                  <div className="vh-view-all-btns d-flex align-items-center">
                    <a href="#" className="btn btn-primary vh-btn-lg">
                      View all
                    </a>
                    <a href="#" className="btn btn-outline-primary vh-btn-lg">
                      Manage
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </AuthLayout>
  );
};
export default DoctorPage;
