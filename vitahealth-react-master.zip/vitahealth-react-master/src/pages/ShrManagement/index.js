import AuthLayout from "layouts/AuthLayout";
import VhTable from "components/shared/VhTable";

const ShrManagement = () => {
  const columns = [
    {
      name: "Patient Name",
      selector: (row) => row.name,
    },
    {
      name: "Hospital Name",
      selector: (row) => row.hospitalName,
    },
    {
      name: "General Practitioner",
      selector: (row) => row.practitioner,
    },
    {
      name: "Current Medication",
      selector: (row) => row.medication,
    },
    {
      name: "Day",
      selector: (row) => row.day,
    },
    {
      name: "Date",
      selector: (row) => row.date,
    },
    {
      name: "Status",
      selector: (row) => row.status,
    },
    {
      name: "Action",
      selector: (row) => row.action,
      cell: (row) => (
        <div className="vh-action-btn">
          <a href="#" className="btn btn-outline-primary vh-btn-sm">
            Edit
          </a>
          <a href="#" className="btn btn-outline-primary vh-btn-sm">
            Delete
          </a>
        </div>
      ),
    },
  ];

  const data = [
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "My GP is not listed",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR not Validated",
    },
    {
      name: "John Doe",
      hospitalName: "Saint Jones",
      practitioner: "I dont have a GP",
      medication: "Heart Surgery",
      day: "Monday",
      date: "12-Dec-2022",
      status: "SHR Validated",
    },
  ];
  return (
    <AuthLayout>
      <section className="section">
        <div className="vh-page-title d-flex justify-content-between align-items-center">
          <div className="vh-haeder-block">
            <h2 className="vh-title mb-0">SHR Management</h2>
            <nav
              className="vh-breadvrumb"
              style={{ "--bs-breadcrumb-divider": "-" }}
              aria-label="breadcrumb"
            >
              <ol className="breadcrumb mb-0">
                <li className="breadcrumb-item">
                  <a href="#">Dashboard</a>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Appointments
                </li>
              </ol>
            </nav>
          </div>
          <a href="#" className="btn btn-outline-primary text-uppercase">
            ADD SHR Report
          </a>
        </div>
        <div className="card">
          <div className="vh-filter-header">
            <div className="vh-filter">
              <form>
                <h4 className="mb-0">Filter</h4>
                <div className="form-group mb-0">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="ID"
                  />
                </div>
                <div className="form-group mb-0">
                  <select className="form-control">
                    <option>By Hospital</option>
                    <option>Confirm</option>
                    <option>Pending</option>
                  </select>
                </div>
                <div className="form-group mb-0">
                  <select className="form-control">
                    <option>By Status</option>
                    <option>Saint Jones</option>
                    <option>Johnson Doe</option>
                  </select>
                </div>
                <input
                  type="date"
                  className="btn btn-primary dateBtn"
                  defaultValue="By dd/mm/yyyy"
                />
                <button type="submit" className="btn btn-primary">
                  Apply Filter
                </button>
              </form>
            </div>
            <div className="vh-search-element">
              <input
                className="form-control"
                type="search"
                placeholder="Search"
                aria-label="Search"
                data-width="250"
              />
              <button className="btn" type="submit">
                <i className="fas fa-search"></i>
              </button>
            </div>
          </div>
          <div className="vh-card-body">
            <div className="vh-appointment-table">
              <VhTable columns={columns} data={data} />
            </div>
          </div>
        </div>
      </section>
    </AuthLayout>
  );
};
export default ShrManagement;
