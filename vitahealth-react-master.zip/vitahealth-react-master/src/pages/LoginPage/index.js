import GuestHeader from "partials/Header/GuestHeader";
import { useDispatch, useSelector } from "react-redux";
import { doLogin, userSelector } from "slices/user";
import { useState, useEffect } from "react";
import { redirect, useNavigate } from "react-router-dom";

const LoginPage = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { user, loading, hasErrors } = useSelector(userSelector);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isActive, setActive] = useState(false);
  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(
      doLogin({ email, password }, () => {
        setEmail("");
        setPassword("");
        navigate(`/`);
      })
    );
  };

  useEffect(() => {
    setActive(email?.length < 3 && password.length < 5);
  }, [email, password]);

  if (user) {
    redirect("/");
  }
  return (
    <>
      <div className="vh-log-reg-body">
        <div className="container-fluid">
          <GuestHeader />
          <div className="vh-customer-form vh-login-form">
            <form
              action="#"
              onSubmit={(e) => {
                handleSubmit(e);
              }}
            >
              <div className="vh-form-block-1">
                <h5>Vita Health Log in</h5>
                <div className="form-group form-floating">
                  <input
                    type="email"
                    className="form-control"
                    id="emailaddress"
                    onChange={(e) => {
                      setEmail(e?.target?.value);
                    }}
                    value={email}
                    placeholder="Email Address"
                  />
                  <label htmlFor="emailaddress">Email Address</label>
                </div>
                <div className="form-group form-floating mb-2">
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    onChange={(e) => {
                      setPassword(e?.target?.value);
                    }}
                    value={password}
                    placeholder="Password"
                  />
                  <label htmlFor="password">Password</label>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-check vh-custom-checkbox">
                      {/* <label className="form-check-label ps-2" htmlFor="Remember">
                        <input className="form-check-input" type="checkbox" defaultValue id="Remember" />
                        Remember Me
                        <span className="vh-custom-checkmark" />
                      </label> */}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <a
                      href="#"
                      className="vh-forgot-pass-link ms-0 ms-md-auto mt-3 mt-md-0 d-table text-primary text-decoration-none"
                    >
                      Forgot Password
                    </a>
                  </div>
                </div>
              </div>
              <button
                type="submit"
                disabled={isActive && !loading}
                className="btn btn-primary mt-5 text-uppercase vh-btn-xl w-100"
              >
                Login
              </button>
            </form>
          </div>
        </div>
      </div>
      <footer>
        <p className="mb-0">Copyright © Vita Health 2022.</p>
      </footer>
    </>
  );
};
export default LoginPage;
