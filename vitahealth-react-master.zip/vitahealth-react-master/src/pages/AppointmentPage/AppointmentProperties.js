import AuthLayout from "layouts/AuthLayout";

const AppointmentProperties = () => {
  return (
    <AuthLayout>
      <section className="section">
        <div className="vh-page-title d-flex justify-content-between align-items-center">
          <div className="vh-haeder-block">
            <h2 className="vh-title mb-0">Make Appointment</h2>
            <nav
              className="vh-breadvrumb"
              style={{ "--bs-breadcrumb-divider": '"-"' }}
              aria-label="breadcrumb"
            >
              <ol className="breadcrumb mb-0">
                <li className="breadcrumb-item">
                  <a href="#">Dashboard</a>
                </li>
                <li className="breadcrumb-item">
                  <a href="#">Appointments</a>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Make Appointment
                </li>
              </ol>
            </nav>
          </div>
        </div>
        <div className="card">
          <div className="vh-card-title d-flex justify-content-between align-items-center">
            <h3 className="vh-sub-title">Make an Appointment</h3>
            <div className="vh-appoinment-select-patient d-flex">
              <div className="vh-custom-radio">
                <label className="text-primary">
                  New Patient
                  <input type="radio" name="select patient" defaultChecked />
                  <span className="vh-radio-check" />
                </label>
              </div>
              <div className="vh-custom-radio ms-4">
                <label className="text-primary">
                  Old Patient
                  <input type="radio" name="select patient" />
                  <span className="vh-radio-check" />
                </label>
              </div>
            </div>
          </div>
          <div className="vh-make-appoint-form">
            <form>
              <div className="row gx-4">
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="text"
                      className="form-control"
                      id="firstName"
                      placeholder="First Name"
                    />
                    <label htmlFor="firstName">First Name*</label>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="text"
                      className="form-control"
                      id="lastName"
                      placeholder="Last Name"
                    />
                    <label htmlFor="lastName">Last Name*</label>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <select className="form-control" id="gender">
                      <option value>Select Gender</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="email"
                      className="form-control"
                      id="email"
                      placeholder="Email"
                    />
                    <label htmlFor="email">Email*</label>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="password"
                      className="form-control"
                      id="password"
                      placeholder="Password"
                    />
                    <label htmlFor="password">Password*</label>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="password"
                      className="form-control"
                      id="confirmPassword"
                      placeholder="Confirm Password"
                    />
                    <label htmlFor="confirmPassword">Confirm Password*</label>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <select className="form-control" id="selectService">
                      <option value>Select Service</option>
                      <option value="Heart Surgery">Heart Surgery</option>
                      <option value="Kidney Test">Kidney Test</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <select className="form-control" id="selectHospitals">
                      <option value>Select Hospitals</option>
                      <option value="Saint Jones">Saint Jones</option>
                      <option value="Saint Joseph">Saint Joseph</option>
                    </select>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="form-group form-floating">
                    <input
                      type="date"
                      className="form-control"
                      id="selectDate"
                      placeholder="Select Date"
                    />
                    <label htmlFor="selectDate">Select Date*</label>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group form-floating">
                    <textarea
                      className="form-control"
                      placeholder="Enter Description"
                      defaultValue={""}
                    />
                    <label htmlFor="selectDate">Enter Description*</label>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="form-group vh-file-block form-control">
                    <div className="vh-custom-file-upload">
                      <label>Add Medical Report</label>
                      <input type="file" className="form-contol" />
                    </div>
                  </div>
                </div>
                <div className="col-12">
                  <div className="vh-available-slot form-control">
                    <div className="vh-slot-title">
                      <h5 className="mb-0">
                        Tuesday,{" "}
                        <span className="vh-slot-date">27-December-2022</span>
                        <span className="vh-slot-time">
                          {" "}
                          (10:00am - 05:00pm)
                        </span>
                      </h5>
                    </div>
                    <div className="vh-slot-selection">
                      <h6 className="mb-0 text-primary">Availble Slots:</h6>
                      <div className="vh-slot-listing">
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="10:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="10:00"
                          >
                            10:00am
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="10:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="10:30"
                          >
                            10:30am
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="11:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="11:00"
                          >
                            11:00am
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="11:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="11:30"
                          >
                            11:30am
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="12:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="12:00"
                          >
                            12:00pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="12:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="12:30"
                          >
                            12:30pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="01:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="01:00"
                          >
                            01:00pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="01:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="01:30"
                          >
                            01:30pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="02:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="02:00"
                          >
                            02:00pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="02:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="02:30"
                          >
                            02:30pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="03:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="03:00"
                          >
                            03:00pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="03:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="03:30"
                          >
                            03:30pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="03:45"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="03:45"
                          >
                            03:45pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="04:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="03:00"
                          >
                            04:00pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="04:20"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="04:20"
                          >
                            04:20pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="04:30"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="04:30"
                          >
                            04:30pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="04:45"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="04:45"
                          >
                            04:45pm
                          </label>
                        </div>
                        <div className="vh-slot-check">
                          <input
                            type="radio"
                            className="btn-check"
                            name="Select slot"
                            id="05:00"
                            autoComplete="off"
                          />
                          <label
                            className="btn btn-outline-primary"
                            htmlFor="05:00"
                          >
                            05:00pm
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="vh-appointment-btn-group mt-5">
                <input
                  type="submit"
                  className="btn btn-primary vh-btn-lg"
                  defaultValue="Save"
                />
                <input
                  type="reset"
                  className="btn btn-outline-primary vh-btn-lg"
                  defaultValue="Cancel"
                />
              </div>
            </form>
          </div>
        </div>
      </section>
    </AuthLayout>
  );
};

export default AppointmentProperties;
