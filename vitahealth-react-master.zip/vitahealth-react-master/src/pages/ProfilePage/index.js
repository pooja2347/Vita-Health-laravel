import { Formik } from "formik";
import { useState, useEffect } from "react";
import Avatar from "components/Avatar";
import AuthLayout from "layouts/AuthLayout";
import { useSelector } from "react-redux";
import { userSelector, updateUserPassword } from "slices/user";

const ProfilePage = () => {
  const [isChangePassword, setChangePassword] = useState(false);
  const [isEditProfile, setEditProfile] = useState(false);
  const [isChangeImage, setChangeImage] = useState(false);
  const [currentPassword, setCurrentPassword] = useState(null);
  const [newPassword, setNewPassword] = useState(null);
  const [confirmPassword, setConfirmPassword] = useState(null);

  const { user, loading } = useSelector(userSelector);

  const toggleChangeImage = (e) => {
    e.preventDefault();
    setChangeImage(true);
  };
  const toggleChangePassword = (e) => {
    e.preventDefault();
    setChangePassword(!isChangePassword);
  };

  const handleChangePassword = (e) => {
    e.preventDefault();
    dispatchEvent(
      updateUserPassword(
        { currentPassword, newPassword, confirmPassword },
        () => {
          setCurrentPassword(null);
          setNewPassword(null);
          setConfirmPassword(null);
        }
      )
    );
  };

  const handleCancelEdit = () => {
    setEditProfile(false);
  };
  return (
    <>
      <AuthLayout>
        <section className="section">
          <div className="vh-page-title d-flex justify-content-between align-items-center">
            <div className="vh-haeder-block">
              <h2 className="vh-title mb-0">Profile Management</h2>
              <nav
                className="vh-breadvrumb"
                style={{ "--bs-breadcrumb-divider": "-" }}
                aria-label="breadcrumb"
              >
                <ol className="breadcrumb mb-0">
                  <li className="breadcrumb-item">
                    <a href="#">Dashboard</a>
                  </li>
                  <li className="breadcrumb-item active" aria-current="page">
                    Profile
                  </li>
                </ol>
              </nav>
            </div>
          </div>
          <div className="vh-profile-outer d-flex flex-wrap justify-content-between">
            <div className="vh-profile-left">
              <div className="card mb-0 h-100">
                <div className="vh-card-title justify-content-center">
                  <h3 className="vh-sub-title text-uppercase text-body">
                    My Profile
                  </h3>
                </div>
                <div className="vh-profile-img-outer">
                  <div className="vh-profile-img">
                    <Avatar
                      name={`${user?.firstname} ${user?.lastname}`}
                      size={150}
                      round="150px"
                    />
                  </div>
                  <div className="vh-view-all-btns d-flex justify-content-center align-items-center">
                    <a
                      href="#"
                      onClick={(e) => {
                        toggleChangeImage(e);
                      }}
                      className="btn btn-outline-primary"
                    >
                      Change your image
                    </a>
                    <a
                      href="#"
                      onClick={(e) => {
                        toggleChangePassword(e);
                      }}
                      className="btn btn-outline-primary"
                    >
                      Change Password
                    </a>
                  </div>
                </div>
                {isChangePassword ? (
                  <div className="vh-change-password">
                    <Formik
                      initialValues={{
                        currentPassword: "",
                        newPassword: "",
                        confirmPassword: "",
                      }}
                      validate={(values) => {
                        const errors = {};

                        return errors;
                      }}
                      onSubmit={(values, { setSubmitting }) => {
                        setTimeout(() => {
                          alert(JSON.stringify(values, null, 2));
                          setSubmitting(false);
                        }, 400);
                      }}
                    >
                      {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        isSubmitting,
                      }) => (
                        <form onSubmit={handleChangePassword}>
                          <p className="text-uppercase text-body">
                            Change Password
                          </p>
                          <div className="form-group form-floating">
                            <input
                              type="password"
                              className="form-control"
                              id="currentPassword"
                              name="currentPassword"
                              value={values?.currentPassword}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              placeholder="Current Password"
                            />
                            <label htmlFor="currentPassword">
                              Current Password
                            </label>
                            <div className="text-danger">
                              {errors.currentPassword &&
                                touched.currentPassword &&
                                errors.currentPassword}
                            </div>
                          </div>
                          <div className="form-group form-floating">
                            <input
                              type="password"
                              className="form-control"
                              id="newPassword"
                              name="newPassword"
                              value={values?.newPassword}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              placeholder="New Password"
                            />
                            <label htmlFor="newPassword">New Password</label>
                            <div className="text-danger">
                              {errors.newPassword &&
                                touched.newPassword &&
                                errors.newPassword}
                            </div>
                          </div>
                          <div className="form-group form-floating">
                            <input
                              type="password"
                              className="form-control"
                              id="confirmPassword"
                              name="confirmPassword"
                              value={values?.confirmPassword}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              placeholder="Confirm Password"
                            />
                            <label htmlFor="confirmPassword">
                              Confirm Password
                            </label>
                            <div className="text-danger">
                              {errors.confirmPassword &&
                                touched.confirmPassword &&
                                errors.confirmPassword}
                            </div>
                          </div>
                          <input
                            type="Submit"
                            className="btn btn-primary vh-btn-lg"
                            value="Change Password"
                          />
                        </form>
                      )}
                    </Formik>
                  </div>
                ) : (
                  <>
                    <div className="vh-user-detail">
                      <ul className="list-unstyled d-flex flex-column mx-auto">
                        <li className="vh-username">
                          <span className="vh-user-detail-label">Name:</span>
                          <span className="vh-user-value">
                            {user?.firstname} {user?.lastname}
                          </span>
                        </li>
                        <li>
                          <span className="vh-user-detail-label">Email:</span>
                          <span className="vh-user-value">{user?.email}</span>
                        </li>
                        <li>
                          <span className="vh-user-detail-label">Phone:</span>
                          <span className="vh-user-value">{user?.phone}</span>
                        </li>
                        <li>
                          <span className="vh-user-detail-label">Gender:</span>
                          <span className="vh-user-value">{user?.gender}</span>
                        </li>
                        <li>
                          <span className="vh-user-detail-label">
                            Date of Birth:
                          </span>
                          <span className="vh-user-value">{user?.dob}</span>
                        </li>
                        <li>
                          <span className="vh-user-detail-label">
                            Blood Group:
                          </span>
                          <span className="vh-user-value">
                            {user?.blood_group}
                          </span>
                        </li>
                      </ul>
                    </div>
                    <div className="vh-user-detail vh-user-address">
                      <ul className="list-unstyled mx-auto">
                        <li>
                          <span className="vh-user-detail-label">Address:</span>
                          <span className="vh-user-value">{user?.address}</span>
                        </li>
                      </ul>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="vh-profile-right">
              <div className="card mb-0">
                <div className="vh-card-title d-flex justify-content-between align-items-center">
                  <h3 className="vh-sub-title">
                    {isEditProfile ? "Edit Profile" : "Profile"}
                  </h3>
                  <div className="vh-button-group">
                    {isEditProfile ? (
                      <button className="btn btn-outline-primary">Save</button>
                    ) : (
                      <button
                        className="btn btn-outline-primary"
                        onClick={() => {
                          setEditProfile(true);
                        }}
                      >
                        Edit Profile
                      </button>
                    )}
                  </div>
                </div>
                <div className="vh-profile-form">
                  <Formik
                    initialValues={{
                      firstName: "",
                      lastName: "",
                      email: "",
                      phone: "",
                      dob: "",
                      gender: "",
                      bloodGroup: "",
                      country: "",
                      addressLine1: "",
                      addressLine2: "",
                      city: "",
                    }}
                    validate={(values) => {
                      const errors = {};
                      if (!values.email) {
                        errors.email = "Required";
                      } else if (
                        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
                          values.email
                        )
                      ) {
                        errors.email = "Invalid email address";
                      }
                      return errors;
                    }}
                    onSubmit={(values, { setSubmitting }) => {
                      setTimeout(() => {
                        alert(JSON.stringify(values, null, 2));
                        setSubmitting(false);
                      }, 400);
                    }}
                  >
                    {({
                      values,
                      errors,
                      touched,
                      handleChange,
                      handleBlur,
                      handleSubmit,
                      isSubmitting,
                    }) => (
                      <form>
                        <div className="vh-basic-info">
                          <p className="text-uppercase text-body">
                            Basic Information
                          </p>
                          <div className="row">
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="firstName"
                                  name="firstName"
                                  placeholder="First Name"
                                  value={values?.firstName}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="firstName">First Name*</label>
                                <div className="text-danger">
                                  {errors.firstName &&
                                    touched.firstName &&
                                    errors.firstName}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="lastName"
                                  placeholder="Last Name"
                                  name="lastName"
                                  value={values?.lastName}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="lastName">Last Name*</label>
                                <div className="text-danger">
                                  {errors.lastName &&
                                    touched.lastName &&
                                    errors.lastName}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="email"
                                  className="form-control"
                                  id="emailAddress"
                                  placeholder="Email Address"
                                  name="email"
                                  value={values?.email}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="emailAddress">
                                  Email Address*
                                </label>
                                <div className="text-danger">
                                  {errors.email &&
                                    touched.email &&
                                    errors.email}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="contactNumber"
                                  name="phone"
                                  placeholder="Contact No"
                                  value={values?.phone}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="contactNumber">
                                  Contact No*
                                </label>
                                <div className="text-danger">
                                  {errors.phone &&
                                    touched.phone &&
                                    errors.phone}
                                </div>
                              </div>
                            </div>

                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="date"
                                  className="form-control"
                                  id="dob"
                                  name="dob"
                                  placeholder="Date of Birth"
                                  value={values?.dob}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="dateofBirth">
                                  Date of Birth*
                                </label>
                                <div className="text-danger">
                                  {errors.dob && touched.dob && errors.dob}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <select
                                  className="form-control"
                                  name="gender"
                                  value={values?.gender}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                >
                                  <option value={"male"}>Male</option>
                                  <option value={"female"}>Female</option>
                                </select>
                                <label>Gender*</label>
                                <div className="text-danger">
                                  {errors.gender &&
                                    touched.gender &&
                                    errors.gender}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <select
                                  className="form-control"
                                  name="bloodGroup"
                                  value={values?.bloodGroup}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                >
                                  <option value="A+">A+</option>
                                  <option value="A-">A-</option>
                                  <option value="AB+">AB+</option>
                                  <option value="AB-">AB-</option>
                                  <option value="B+">B+</option>
                                  <option value="B-">B-</option>
                                  <option value="O+">O+</option>
                                  <option value="O-">O-</option>
                                </select>
                                <label>Blood Group</label>
                                <div className="text-danger">
                                  {errors.bloodGroup &&
                                    touched.bloodGroup &&
                                    errors.bloodGroup}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="vh-contact-info">
                          <p className="text-uppercase text-body">
                            Contact Information
                          </p>
                          <div className="row">
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <select
                                  className="form-control"
                                  name="country"
                                  value={values?.country}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                >
                                  <option>Country Name</option>
                                </select>
                                <label>Country*</label>
                                <div className="text-danger">
                                  {errors.country &&
                                    touched.country &&
                                    errors.country}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="addressLine1"
                                  name="addressLine1"
                                  placeholder="Address"
                                  value={values?.addressLine1}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="addressLine1">Address*</label>
                                <div className="text-danger">
                                  {errors.addressLine1 &&
                                    touched.addressLine1 &&
                                    errors.addressLine1}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="addressLine2"
                                  name="addressLine2"
                                  placeholder="Address Line 2"
                                  value={values?.addressLine2}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="address">
                                  Address Line 2 (optional)
                                </label>
                                <div className="text-danger">
                                  {errors.addressLine2 &&
                                    touched.addressLine2 &&
                                    errors.addressLine2}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="city"
                                  name="city"
                                  placeholder="State/City"
                                  value={values?.city}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="city">State/City</label>
                                <div className="text-danger">
                                  {errors.city && touched.city && errors.city}
                                </div>
                              </div>
                            </div>
                            <div className="col-md-6">
                              <div className="form-group form-floating">
                                <input
                                  type="text"
                                  className="form-control"
                                  id="zip"
                                  name="zip"
                                  placeholder="Postal Code"
                                  value={values?.zip}
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  disabled={!isEditProfile}
                                />
                                <label htmlFor="postalCode">Postal Code*</label>
                                <div className="text-danger">
                                  {errors.zip && touched.zip && errors.zip}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        {isEditProfile && (
                          <div className="vh-appointment-btn-group">
                            <button
                              type="submit"
                              className="btn btn-primary vh-btn-lg"
                              disabled={isSubmitting}
                            >
                              Save
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="btn btn-outline-primary vh-btn-lg"
                            >
                              Cancel
                            </button>
                          </div>
                        )}
                      </form>
                    )}
                  </Formik>
                </div>
              </div>
            </div>
          </div>
          {/* <div className="vh-qualification-info mt-4 pt-2">
            <div className="card">
              <div className="vh-card-title d-flex justify-content-between align-items-center border-0">
                <h3 className="vh-sub-title">Qualifications Information</h3>
                <div className="vh-button-group">
                  <a href="#" className="btn btn-outline-primary">
                    Save
                  </a>
                </div>
              </div>
              <div className="table-responsive">
                <table className="table thead-with-bg table-bordered mb-0">
                  <thead>
                    <tr>
                      <th className="text-uppercase" scope="col">
                        Sr No.
                      </th>
                      <th className="text-uppercase" scope="col">
                        Degree
                      </th>
                      <th className="text-uppercase" scope="col">
                        University
                      </th>
                      <th className="text-uppercase" scope="col">
                        Year
                      </th>
                      <th className="text-uppercase" scope="col">
                        Action
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Johnson</td>
                      <td>Heart Surgery</td>
                      <td>12-Dec-2022</td>
                      <td>00:00am</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Johnson</td>
                      <td>Heart Surgery</td>
                      <td>12-Dec-2022</td>
                      <td>00:00am</td>
                      <td>
                        <div className="vh-action-btn">
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Edit
                          </a>
                          <a
                            href="#"
                            className="btn btn-outline-primary vh-btn-sm"
                          >
                            Delete
                          </a>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="vh-basic-info mt-4 pt-2">
                <p className="text-uppercase text-body pt-0">
                  Add Qualifications
                </p>
                <div className="vh-qualification-row">
                  <div className="vh-col-qualification">
                    <div className="form-group form-floating mb-0">
                      <input
                        type="text"
                        className="form-control"
                        id="degree"
                        placeholder="Degree"
                        value="Enter Degree"
                      />
                      <label htmlFor="degree">Degree*</label>
                    </div>
                  </div>
                  <div className="vh-col-qualification">
                    <div className="form-group form-floating mb-0">
                      <input
                        type="text"
                        className="form-control"
                        id="university"
                        placeholder="Enter University"
                        value="Enter University"
                      />
                      <label htmlFor="university">University*</label>
                    </div>
                  </div>
                  <div className="vh-col-qualification">
                    <div className="form-group form-floating mb-0">
                      <select className="form-control">
                        <option>2018</option>
                      </select>
                      <label htmlFor="emailAddress">Select yaer*</label>
                    </div>
                  </div>
                  <div className="vh-col-qualification">
                    <button
                      type="submit"
                      className="btn btn-primary w-100 h-100"
                    >
                      Add Qualifications
                    </button>
                  </div>
                </div>
              </div>
              <div className="vh-appointment-btn-group mt-5">
                <button type="submit" className="btn btn-primary vh-btn-lg">
                  Save
                </button>
                <button
                  type="submit"
                  className="btn btn-outline-primary vh-btn-lg"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div> */}
        </section>
      </AuthLayout>
    </>
  );
};

export default ProfilePage;
