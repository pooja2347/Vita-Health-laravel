import { Link } from "react-router-dom";
import AppointmentCalendar from "components/AppointmentCalendar";
import AuthLayout from "layouts/AuthLayout";
import visitedPatirnt from "assets/img/visited-patient.svg";
import totalAppointment from "assets/img/total-appointment.svg";
import totaltodayAppointment from "assets/img/total-today-services.svg";
import totalServices from "assets/img/total-services.svg";

const HomePage = () => {
  return (
    <>
      <AuthLayout>
        <section className="section">
          <div className="vh-haeder-block">
            <h2 className="vh-title">Welcome to Dashboard</h2>
          </div>
          <div className="vh-dashboard-header-blocks">
            <div className="row">
              <div className="col-lg-6 col-xl-3">
                <div className="card vh-card-border vh-visited-pateint">
                  <div className="vh-card-body">
                    <div className="vh-dash-header-content">
                      <p className="text-orange mb-0">
                        <span>10</span>Total Visited Patient
                      </p>
                      <div className="vh-dash-icon-bg">
                        <img src={visitedPatirnt} alt="Icon" />
                      </div>
                    </div>
                    <div className="vh-dash-header-title">
                      <Link
                        to="/patients"
                        className="mb-0 text-center d-block py-3 px-2"
                      >
                        Manage Patient
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-xl-3">
                <div className="card vh-card-border vh-total-appointment">
                  <div className="vh-card-body">
                    <div className="vh-dash-header-content">
                      <p className="text-green mb-0">
                        <span>16</span>Total Appointments
                      </p>
                      <div className="vh-dash-icon-bg">
                        <img src={totalAppointment} alt="Icon" />
                      </div>
                    </div>
                    <div className="vh-dash-header-title">
                      <Link
                        to="/appointments/new"
                        className="mb-0 text-center d-block py-3 px-2"
                      >
                        Book Appointment on Behalf of your Patient
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-xl-3">
                <div className="card vh-card-border vh-total-today-appointed">
                  <div className="vh-card-body">
                    <div className="vh-dash-header-content">
                      <p className="text-primary mb-0">
                        <span>04</span>Today’s Total Appointments
                      </p>
                      <div className="vh-dash-icon-bg">
                        <img src={totaltodayAppointment} alt="Icon" />
                      </div>
                    </div>
                    <div className="vh-dash-header-title">
                      <Link
                        to="/appointments"
                        className="text-center d-block py-3 px-2"
                      >
                        Manage Appointments
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-xl-3">
                <div className="card vh-card-border vh-total-services">
                  <div className="vh-card-body">
                    <div className="vh-dash-header-content">
                      <p className="text-blue mb-0">
                        <span>02</span>Total Services
                      </p>
                      <div className="vh-dash-icon-bg">
                        <img src={totalServices} alt="Icon" />
                      </div>
                    </div>
                    <div className="vh-dash-header-title">
                      <Link
                        to="#"
                        className="mb-0 d-block text-center py-3 px-2"
                      >
                        Manage Services
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="vh-card-title">
              <h3 className="vh-sub-title">Appointment</h3>
            </div>
            <div className="vh-appointment-cal-sec">
              <AppointmentCalendar />
            </div>
          </div>
        </section>
      </AuthLayout>
    </>
  );
};
export default HomePage;
