import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getConversationById,
  getMessageThreads,
  postMessageById,
  messagesSelector,
} from "slices/messages";
import { fetchUser, userSelector } from "slices/user";
import AuthLayout from "layouts/AuthLayout";
import Pusher from "pusher-js";
import find from "lodash/find";
import filter from "lodash/filter";

const MessagePage = () => {
  const dispatch = useDispatch();
  const {
    conversationLoading,
    threadLoading,
    conversationHasErrors,
    threadHasErrors,
    messages,
    threads,
  } = useSelector(messagesSelector);
  const { user } = useSelector(userSelector);
  const [activeChat, setActiveChat] = useState(null);
  const [activeUser, setActiveUser] = useState(null);
  const [searchKeyword, setSearchKeyword] = useState(null);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [users, setUsers] = useState([]);
  const [userMessage, setUserMessage] = useState(null);

  useEffect(() => {
    dispatch(getMessageThreads());
  }, []);

  useEffect(() => {
    if (!activeChat) {
      setActiveChat(users[0]?.id);
    }
  }, [users]);

  useEffect(() => {
    if (threads) {
      setUsers([...threads]);
    }
  }, [threads]);

  useEffect(() => {
    if (activeChat) {
      let activeUserTemp = find(users, { id: activeChat });
      dispatch(getConversationById({ userId: activeChat }));
      setActiveUser(activeUserTemp);
    }
  }, [activeChat]);

  useEffect(() => {
    if (searchKeyword) {
      let filteredUsersTemp = filter(users, function (item) {
        return item?.name?.toLowerCase().includes(searchKeyword.toLowerCase());
      });
      setFilteredUsers([...filteredUsersTemp]);
    } else {
      setFilteredUsers([...users]);
    }
  }, [searchKeyword, users]);

  const handleMessageSubmit = (e) => {
    e.preventDefault();
    dispatch(
      postMessageById({ message: userMessage, userId: activeChat }, () => {
        setUserMessage("");
      })
    );
  };

  return (
    <AuthLayout>
      <section className="section">
        <div className="vh-page-title d-flex justify-content-between align-items-center">
          <div className="vh-haeder-block">
            <h2 className="vh-title mb-0">Messages</h2>
            <nav
              className="vh-breadvrumb"
              style={{ "--bs-breadcrumb-divider": '"-"' }}
              aria-label="breadcrumb"
            >
              <ol className="breadcrumb mb-0">
                <li className="breadcrumb-item">
                  <a href="#">Dashboard</a>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Messages
                </li>
              </ol>
            </nav>
          </div>
        </div>
        <div className="card">
          <div className="vh-chat-outer">
            <div className="vh-chat-left">
              <div className="vh-chat-left-header">
                <h5>Recent Messages</h5>
                <div className="vh-search-element">
                  <input
                    className="form-control"
                    type="text"
                    placeholder="Search"
                    aria-label="Search"
                    data-width={250}
                    value={searchKeyword}
                    onChange={(e) => {
                      setSearchKeyword(e?.target?.value);
                    }}
                  />
                  <button className="btn" type="submit">
                    <i className="fas fa-search" />
                  </button>
                </div>
              </div>
              <div className="vh-chat-person-section">
                {filteredUsers.map((item, index) => (
                  <div
                    className={
                      activeChat == item?.id
                        ? "vh-chat-person vh-chat-active"
                        : "vh-chat-person"
                    }
                    onClick={() => {
                      setActiveChat(item?.id);
                    }}
                  >
                    <img src={item?.profile_photo_url} alt={item?.name} />
                    <h6>{item?.name}</h6>
                    <span className="vh-chat-time">{item?.humans_time}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="vh-chat-right">
              <div className="vh-chat-right-header">
                <img
                  src={activeUser?.profile_photo_url}
                  alt={activeUser?.name}
                />
                <div className="vh-name-act-status">
                  <h6 className="text-black">{activeUser?.name}</h6>
                  <span className="vh-chat-status text-body d-block">
                    Last seen 10 minutes ago
                  </span>
                </div>
                <div className="vh-chat-menu ms-auto">
                  <a href="#">
                    <i className="fas fa-ellipsis-v" />
                  </a>
                </div>
              </div>
              <div className="vh-chat-body">
                {messages &&
                  messages.map((message, index) => (
                    <>
                      {message?.sender?.id !== user?.id ? (
                        <div className="vh-received-msg">
                          <img
                            src={message?.sender?.profile_photo_url}
                            alt={message?.sender?.name}
                          />
                          <div className="vh-received-msg-text">
                            <span className="vh-received-time">
                              {message?.sender?.name}, {message?.humans_time}
                            </span>
                            <p>{message?.message}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="vh-send-msg">
                          <div className="vh-send-msg-text">
                            <span className="vh-send-time">
                              {message?.sender?.name}, {message?.humans_time}
                            </span>
                            <p>{message?.message}</p>
                          </div>
                        </div>
                      )}
                    </>
                  ))}
              </div>
              <div className="vh-send-msg-field">
                <form onSubmit={handleMessageSubmit}>
                  <input
                    type="text"
                    value={userMessage}
                    onChange={(e) => {
                      setUserMessage(e?.target?.value);
                    }}
                    className="form-control"
                    placeholder="Type a message"
                  />
                  <input type="submit" className="vh-send-msg-btn" />
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </AuthLayout>
  );
};

export default MessagePage;
